<?php
if (!isset($_SESSION)) {
  session_start();
}
$message = null;
if (isset($_SESSION['orders_message'])) {
  $message = $_SESSION['orders_message'];
  unset($_SESSION['orders_message']);
}

include 'assets/php/inventory.php';
$result = readNamaInventory();

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Tables / Orders - EsTeh</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>
  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">
    <div class="d-flex align-items-center justify-content-between">
      <a href="index.php" class="logo d-flex align-items-center">
        <img src="assets/img/logo.png" alt="">
        <span class="d-none d-lg-block">EsTeh</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div><!-- End Logo -->

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        <li class="nav-item dropdown pe-3">
          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <img src="assets/img/profile-img.jpg" alt="Profile" class="rounded-circle">
            <span class="d-none d-md-block dropdown-toggle ps-2"><?php echo $_SESSION['name']; ?></span>
          </a><!-- End Profile Iamge Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
            <li class="dropdown-header">
              <h6><?php echo $_SESSION['name']; ?></h6>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>
            <li>
              <a class="dropdown-item d-flex align-items-center" href="pages-login.php">
                <i class="bi bi-box-arrow-right"></i>
                <span>Sign Out</span>
              </a>
            </li>
          </ul><!-- End Profile Dropdown Items -->
        </li><!-- End Profile Nav -->
      </ul>
    </nav><!-- End Icons Navigation -->
  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
    <ul class="sidebar-nav" id="sidebar-nav">
      <li class="nav-item">
        <a class="nav-link collapsed" href="index.php">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li><!-- End Dashboard Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="inventory_page.php">
          <i class="bi bi-box-seam"></i>
          <span>Inventory</span>
        </a>
      </li><!-- End Profile Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="employee_page.php">
          <i class="bi bi-person-lines-fill"></i>
          <span>Employee</span>
        </a>
      </li><!-- End Profile Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="orders_page.php">
          <i class="bi bi-cart-check"></i>
          <span>Orders</span>
        </a>
      </li><!-- End Profile Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="pages-register.php">
          <i class="bi bi-card-list"></i>
          <span>Register</span>
        </a>
      </li><!-- End Register Page Nav -->
    </ul>
  </aside><!-- End Sidebar-->

  <main id="main" class="main">
    <!-- Toast Notification -->
    <?php if ($message) : ?>
      <div class="position-fixed top-0 end-0 p-3" id="ordersToast" style="z-index: 9999">
        <div id="liveToast" class="toast hide" role="alert" aria-live="assertive" aria-atomic="true">
          <div class="toast-header">
            <img src="assets\img\apple-touch-icon.png" class="rounded me-2" alt="..." width="24" height="24">
            <strong class="me-auto">Admin</strong>
            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
          </div>
          <div class="toast-body">
            <?php echo $message['message']; ?>
          </div>
        </div>
      </div>
    <?php endif; ?>

    <div class="pagetitle">
      <h1>Orders</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item active">Orders</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Orders</h5>
                <!-- Tombol Tambah -->
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#Tambah" id="tambah">Tambah Order</button>
                
                <!-- Modal Tambah -->
                <div class="modal fade" id="Tambah" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="staticBackdropLabel">Order</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <!-- Div untuk pesan konfirmasi -->
                        <div id="confirmationMessage" class="alert alert-success d-none"></div>
                        <!-- Vertical Form -->
                        <form class="row g-3" method="POST" action="assets/php/orders.php">
                          <div class="col-12">
                            <label for="productSelect" class="form-label">Nama Produk</label>
                            <select class="form-select" id="productSelect" name="nama_produk" aria-label="">
                              <option selected>Open this select menu</option>
                              <?php
                              if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                  echo "<option value='" . $row["nama_produk"] . "' data-price='" . $row["harga"] . "'>" . $row["nama_produk"] . "</option>";
                                }
                              } else {
                                echo "<option>No products available</option>";
                              }
                              ?>
                            </select>
                          </div>
                          <div class="col-12">
                            <label for="quantity" class="form-label">Quantity</label>
                            <input type="number" class="form-control" id="quantity" name="quantity" min="1" value="1" required>
                          </div>
                          <div class="col-12">
                            <label for="totalCost" class="form-label">Total Harga</label>
                            <input type="text" class="form-control"  style="background-color: #D3D3D3;"  id="totalCost" name="total_harga" readonly>
                          </div>
                          <div class="col-12">
                            <label for="inputorder_date" class="form-label">Order Date</label>
                            <input type="date" class="form-control" id="inputorder_date" name="order_date" required>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kembali</button>
                            <button type="submit" class="btn btn-primary" name="action" value="create">Simpan</button>
                          </div>
                        </form><!-- Vertical Form -->
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Tables -->
                <table class="table table-light table-striped">
                  <thead>
                    <br><br>
                    <tr>
                      <th>ID</th>
                      <th>Nama Produk</th>
                      <th>Jumlah Order</th>
                      <th>Total Harga</th>
                      <th>Tanggal Pemesanan</th>
                      <th>Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    include 'assets/php/orders.php';
                    $orders = readorders();
                    if (count($orders) > 0) {
                      foreach ($orders as $order) {
                        echo "<tr>";
                        echo "<td>" . $order['id'] . "</td>";
                        echo "<td>" . $order['nama_produk'] . "</td>";
                        echo "<td>" . $order['qty'] . "</td>";
                        echo "<td>" . $order['total_harga'] . "</td>";
                        echo "<td>" . $order['order_date'] . "</td>";
                        echo "<td>";
                        echo "<button class='btn btn-primary edit-orders' data-id='" . $order['id'] . "' data-nama='" . $order['nama_produk'] . "' data-bs-toggle='modal' data-bs-target='#editordersModal'>Edit</button> ";
                        echo "<button class='btn btn-danger delete-orders' data-id='" . $order['id'] . "' data-nama='" . $order['nama_produk'] . "' data-bs-toggle='modal' data-bs-target='#confirmDelete'>Hapus</button>";
                        echo "</td>";
                        echo "</tr>";
                      }
                    } else {
                      echo "<tr><td colspan='4'>No results found</td></tr>";
                    }
                    ?>
                  </tbody>
                </table>

                <!-- Modal Konfirmasi Hapus -->
                <div class="modal fade" id="confirmDelete" tabindex="-1" aria-labelledby="confirmDeleteLabel" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="confirmDeleteLabel">Konfirmasi Hapus order</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        Apakah Anda yakin ingin menghapus order<span id="ordersNameProdukToDelete"></span>?
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <a id="deleteLink" href="#" class="btn btn-danger">Hapus</a>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- End Konfirmasi Hapus -->                

                <!-- Modal Edit Orders -->
                <div class="modal fade" id="editordersModal" tabindex="-1" aria-labelledby="editordersModalLabel" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="editordersModalLabel">Edit order</h5>
                      </div>
                      <div class="modal-body">
                        <form id="editordersForm" action="assets/php/orders.php" method="POST">
                          <div class="mb-3">
                            <label for="edit_orders_id" class="form-label">ID</label>
                            <input type="text" class="form-control" style="background-color: #D3D3D3;" id="edit_orders_id" name="id" value="" readonly>
                          </div>
                          <div class="mb-3">
                            <label for="edit_orders_nama_produk" class="form-label">Nama Produk</label>
                            <input type="text" class="form-control" style="background-color: #D3D3D3;" id="edit_orders_nama_produk" name="nama_produk" readonly>
                          </div>
                          <div class="mb-3">
                            <label for="edit_orders_total_harga" class="form-label">Jumlah</label>
                            <input type="decimal" class="form-control" id="edit_orders_total_harga" style="background-color: #D3D3D3;" name="total_harga" readonly>
                          </div>
                          <div class="mb-3">
                            <label for="edit_orders_order_date" class="form-label">Order date</label>
                            <input type="date" class="form-control" id="edit_orders_order_date" name="order_date" required>
                          </div>
                          <div class="modal-footer">
                            <button type="submit" class="btn btn-primary" name="action" value="update">Simpan Perubahan</button>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div><!-- End Edit Orders -->
              </div>
            </div>
          </div>
        </div>
    </section>
    <div class="container mt-4">
  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>EsTeh</span></strong>. All Rights Reserved
    </div>
    <div class="credits">Designed by <a href="https://getbootstrap.com/docs/5.3/getting-started/introduction/">Bootstrap</a></div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

  <!-- Element -->
  <script>
    <?php if ($message) : ?>
      var toastElement = document.getElementById('ordersToast');
      var toast = new bootstrap.Toast(liveToast);
      toast.show();
    <?php endif; ?>
  </script>

  <!-- Code injected by live-server -->
  <script>
    if ('WebSocket' in window) {
      (function() {
        function refreshCSS() {
          var sheets = [].slice.call(document.getElementsByTagName("link"));
          var head = document.getElementsByTagName("head")[0];
          for (var i = 0; i < sheets.length; ++i) {
            var elem = sheets[i];
            var parent = elem.parentElement || head;
            parent.removeChild(elem);
            var rel = elem.rel;
            if (elem.href && typeof rel != "string" || rel.length == 0 || rel.toLowerCase() == "stylesheet") {
              var url = elem.href.replace(/(&|\?)_cacheOverride=\d+/, '');
              elem.href = url + (url.indexOf('?') >= 0 ? '&' : '?') + '_cacheOverride=' + (new Date().valueOf());
            }
            parent.appendChild(elem);
          }
        }
        var protocol = window.location.protocol === 'http:' ? 'ws://' : 'wss://';
        var address = protocol + window.location.host + window.location.pathname + '/ws';
        var socket = new WebSocket(address);
        socket.onmessage = function(msg) {
          if (msg.data == 'reload') window.location.reload();
          else if (msg.data == 'refreshcss') refreshCSS();
        };
        if (sessionStorage && !sessionStorage.getItem('IsThisFirstTime_Log_From_LiveServer')) {
          console.log('Live reload enabled.');
          sessionStorage.setItem('IsThisFirstTime_Log_From_LiveServer', true);
        }
      })();
    } else {
      console.error('Upgrade your browser. This Browser is NOT supported WebSocket for Live-Reloading.');
    }
    // ]]>
  </script>

  <!-- Script Untuk Edit Order -->
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      // Mengatur data yang akan di-edit saat tombol "Edit" diklik
      var editButtons = document.querySelectorAll('.edit-orders');
      editButtons.forEach(function(button) {
        button.addEventListener('click', function() {
          var ordersId = button.getAttribute('data-id');
          var ordersProdukId = button.closest('tr').querySelector('td:nth-child(2)').textContent.trim();
          var ordersTotalHarga = button.closest('tr').querySelector('td:nth-child(3)').textContent.trim();
          var ordersOrderDate = button.closest('tr').querySelector('td:nth-child(5)').textContent.trim();

          // Mengisi nilai input di dalam modal edit
          document.getElementById('edit_orders_id').value = ordersId;
          document.getElementById('edit_orders_nama_produk').value = ordersProdukId;
          document.getElementById('edit_orders_total_harga').value = ordersTotalHarga;
          document.getElementById('edit_orders_order_date').value = ordersOrderDate;

          // Tampilkan modal edit
          var editordersModal = new bootstrap.Modal(document.getElementById('editordersModal'));
          editordersModal.show();
        });
      });
    });
  </script>

  <!-- Script Untuk Hapus Order -->
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      var deleteButtons = document.querySelectorAll('.delete-orders');
      deleteButtons.forEach(function(button) {
        button.addEventListener('click', function() {
          var ordersProdukId = button.getAttribute('data-nama');
          var ordersId = button.getAttribute('data-id');
          document.getElementById('ordersNameProdukToDelete').textContent = ordersProdukId;
          var deleteLink = document.getElementById('deleteLink');
          deleteLink.setAttribute('href', 'assets/php/orders.php?id=' + ordersId);
        });
      });
    });
  </script>

  <!-- Script Untuk Pilih Nama (Label Dropdown) Order -->
  <script>
    $(document).ready(function() {
      // Fetch products on modal show
      $('#Tambah').on('show.bs.modal', function() {
        $.ajax({
          url: 'assets/php/getInventory.php',
          type: 'GET',
          dataType: 'json',
          success: function(data) {
            console.log("Data received: ", data); // Debugging log
            var productSelect = $('#productSelect');
            productSelect.empty();
            productSelect.append('<option selected>Choose...</option>');
            data.forEach(function(inventory) {
              var option = $('<option></option>').text(inventory.nama_produk).val(inventory.id).data('price', inventory.total_harga);
              productSelect.append(option);
            });
          },
          error: function(jqXHR, textStatus, errorThrown) {
            console.error('Error fetching products:', textStatus, errorThrown);
          }
        });
      });

      // Update total cost when quantity or product changes
      $('#quantity, #productSelect').on('change', function() {
        var quantity = $('#quantity').val();
        var productPrice = $('#productSelect option:selected').data('price');
        var totalCost = quantity * productPrice;
        $('#totalCost').val(totalCost);
      });
    });
  </script>

  <!-- Script Untuk Auto Kalkulasi Total Harga Order -->
  <script>
    // JavaScript for calculating total cost
    document.getElementById('productSelect').addEventListener('change', function() {
      calculateTotal();
    });

    document.getElementById('quantity').addEventListener('input', function() {
      calculateTotal();
    });

    function calculateTotal() {
      // Get selected product price
      var productSelect = document.getElementById('productSelect');
      var selectedOption = productSelect.options[productSelect.selectedIndex];
      var productPrice = selectedOption.getAttribute('data-price');

      // Get quantity
      var quantity = document.getElementById('quantity').value;

      // Calculate total cost
      var totalCost = productPrice * quantity;

      // Update total cost input field
      document.getElementById('totalCost').value = totalCost;
    }
  </script>
</body>
</html>