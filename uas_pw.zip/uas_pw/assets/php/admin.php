<?php
if (!isset($_SESSION)) {
    session_start();
}

include 'connect.php';

function createAdmin($nama, $email, $username, $password) {
    global $conn;
    $sql = "INSERT INTO admin (nama, email, username, password) VALUES ('$nama', '$email', '$username', '$password')";
    if ($conn->query($sql) === TRUE) {
        $_SESSION['admin_message'] = ["type" => "success", "message" => "Admin berhasil ditambahkan! Silahkan menuju halaman Log In"];
    } else {
        $_SESSION['admin_message'] = ["type" => "danger", "message" => "Error: " . $sql . "<br>" . $conn->error];
    }
}

function readAdmins() {
    global $conn;
    $sql = "SELECT * FROM admin";
    $result = $conn->query($sql);
    $admins = array();
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $admins[] = $row;
        }
    }
    return $admins;
}

function updateAdmin($id, $nama, $email, $username, $password) {
    global $conn;
    $sql = "UPDATE admin SET nama='$nama', email='$email', username='$username', password='$password' WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        $_SESSION['admin_message'] = ["type" => "success", "message" => "Admin berhasil diupdate!"];
    } else {
        $_SESSION['admin_message'] = ["type" => "danger", "message" => "Error updating record: " . $conn->error];
    }
}

function deleteAdmin($id) {
    global $conn;
    $sql = "DELETE FROM admin WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        $_SESSION['admin_message'] = ["type" => "success", "message" => "Admin berhasil dihapus!"];
    } else {
        $_SESSION['admin_message'] = ["type" => "danger", "message" => "Error deleting record: " . $conn->error];
    }
}

function loginAdmin($username, $password) {
    global $conn;
    $sql = "SELECT * FROM admin WHERE username = '$username' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $_SESSION['username'] = $username;
        $_SESSION['name'] = $user['nama'];
        header("Location: /UAS_PW/index.php");
        exit();
    } else {
        $_SESSION['admin_message'] = ["type" => "danger", "message" => "Invalid Username or Password"];
        header("Location: /UAS_PW/pages-login.php");
        exit();
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    switch($action) {
        case 'create':
            $nama = $_POST['nama'];
            $email = $_POST['email'];
            $username = $_POST['username'];
            $password = $_POST['password'];
            createAdmin($nama, $email, $username, $password);
            break;

        case 'read':
            $response = json_encode(readAdmins());
            break;

        case 'update':
            $id = $_POST['id'];
            $nama = $_POST['nama'];
            $email = $_POST['email'];
            $username = $_POST['username'];
            $password = $_POST['password'];
            updateAdmin($id, $nama, $email, $username, $password);
            break;

        case 'delete':
            $id = $_POST['id'];
            deleteAdmin($id);
            break;

        case 'login':
            $username = $_POST['username'];
            $password = $_POST['password'];
            loginAdmin($username, $password);
            break;
        
        default:
            $_SESSION['admin_message'] = ["type" => "danger", "message" => "Invalid action!"];
            break;
    }

    header("Location: /UAS_PW/pages-register.php"); 
    exit();
}

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id = $_GET['id'];
    deleteAdmin($id);

    header("Location: /UAS_PW/index.php");

    exit();
}
?>

?>
