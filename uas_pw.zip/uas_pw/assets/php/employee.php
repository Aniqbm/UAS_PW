<?php
if (!isset($_SESSION)) {
    session_start();
}

include 'connect.php';

function createEmployee($nama, $posisi, $tanggal_bergabung) {
    global $conn;
    $sql = "INSERT INTO employee (nama, posisi, tanggal_masuk) VALUES ('$nama', '$posisi', '$tanggal_bergabung')";
    if ($conn->query($sql) === TRUE) {
        $_SESSION['employee_message'] = ["type" => "success", "message" => "Karyawan berhasil ditambahkan!"];
    } else {
        $_SESSION['employee_message'] = ["type" => "danger", "message" => "Error: " . $sql . "<br>" . $conn->error];
    }
}

function readEmployees() {
    global $conn;
    $sql = "SELECT * FROM Employee ORDER BY id";
    $result = $conn->query($sql);
    $employees = array();
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $employees[] = $row;
        }
    }
    return $employees;
}

function updateEmployee($id, $nama, $posisi, $tanggal_bergabung) {
    global $conn;
    $sql = "UPDATE Employee SET nama='$nama', posisi='$posisi', tanggal_masuk='$tanggal_bergabung' WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        $_SESSION['employee_message'] = ["type" => "success", "message" => "Karyawan berhasil diupdate!"];
    } else {
        $_SESSION['employee_message'] = ["type" => "danger", "message" => "Error updating record: " . $conn->error];
    }
}

function deleteEmployee($id) {
    global $conn;
    $sql = "DELETE FROM Employee WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        $_SESSION['employee_message'] = ["type" => "success", "message" => "Karyawan berhasil dihapus!"];
    } else {
        $_SESSION['employee_message'] = ["type" => "danger", "message" => "Error deleting record: " . $conn->error];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $response = '';

    switch($action) {
        case 'create':
            $nama = $_POST['nama'];
            $posisi = $_POST['posisi'];
            $tanggal_bergabung = $_POST['tanggal_masuk'];
            createEmployee($nama, $posisi, $tanggal_bergabung);
            break;

        case 'read':
            $response = json_encode(readEmployees());
            break;

        case 'update':
            $id = $_POST['id'];
            $nama = $_POST['nama'];
            $posisi = $_POST['posisi'];
            $tanggal_bergabung = $_POST['tanggal_masuk'];
            updateEmployee($id, $nama, $posisi, $tanggal_bergabung);
            break;

        case 'delete':
            $id = $_POST['id'];
            deleteEmployee($id);
            break;

        default:
            $response = 'Invalid action';
            break;
    }

    header("Location: /UAS_PW/employee_page.php");
    exit();
}

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id = $_GET['id'];
    deleteEmployee($id);

    header("Location: /UAS_PW/employee_page.php");

    exit();
}
?>