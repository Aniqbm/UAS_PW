<?php
include 'connect.php';

#Untuk mengambil data inventory sebagai dropdown label

$sql = "SELECT id, nama_produk, total_harga FROM inventory";
$result = $conn->query($sql);

$inventory = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $inventory[] = $row;
    }
}

header('Content-Type: application/json');
echo json_encode($inventory);
?>