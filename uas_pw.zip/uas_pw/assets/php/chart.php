<?php
include 'connect.php';

#Membuat tampilan chart di Dashboard

function readTotalQtyByDate() {
    global $conn;
    $sql = "SELECT DATE(order_date) AS order_date, SUM(qty) AS total_qty FROM orders GROUP BY DATE(order_date)";
    $result = $conn->query($sql);
    return $result;
}

function readTotalHargaByDate() {
    global $conn;
    $sql = "SELECT DATE(order_date) AS order_date, SUM(total_harga) AS total_revenue FROM orders GROUP BY DATE(order_date)";
    $result = $conn->query($sql);
    return $result;
}

function readTotalIdByDate() {
    global $conn;
    $sql = "SELECT DATE(order_date) AS order_date, COUNT(id) AS total_customers FROM orders GROUP BY DATE(order_date)";
    $result = $conn->query($sql);
    return $result;
}

$data = [];

$totalQtyResult = readTotalQtyByDate();
if ($totalQtyResult) {
    while ($row = $totalQtyResult->fetch_assoc()) {
        $data['qty'][] = ['date' => $row['order_date'], 'total' => $row['total_qty']];
    }
}

$totalRevenueResult = readTotalHargaByDate();
if ($totalRevenueResult) {
    while ($row = $totalRevenueResult->fetch_assoc()) {
        $data['revenue'][] = ['date' => $row['order_date'], 'total' => $row['total_revenue']];
    }
}

$totalCustomersResult = readTotalIdByDate();
if ($totalCustomersResult) {
    while ($row = $totalCustomersResult->fetch_assoc()) {
        $data['customers'][] = ['date' => $row['order_date'], 'total' => $row['total_customers']];
    }
}

$conn->close();

echo json_encode($data);
?>
