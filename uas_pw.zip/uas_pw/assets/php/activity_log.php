<?php
include 'connect.php';

$query = "SELECT * FROM activity_log ORDER BY activity_time DESC";
$result = $conn->query($query);
?>
