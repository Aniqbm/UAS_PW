<?php
if (!isset($_SESSION)) {
    session_start();
}

include 'connect.php';

function createInventory($nama_produk, $stok, $harga) {
    global $conn;
    $sql = "INSERT INTO inventory (nama_produk, stok, harga) VALUES ('$nama_produk', '$stok', '$harga')";
    if ($conn->query($sql) === TRUE) {
        $_SESSION['inventory_message'] = ["type" => "success", "message" => "Barang berhasil ditambahkan!"];
    } else {
        $_SESSION['inventory_message'] = ["type" => "danger", "message" => "Error: " . $sql . "<br>" . $conn->error];
    }
}

function readNamaInventory() {
    global $conn;
    $sql = "SELECT nama_produk, harga FROM inventory";
    $result = $conn->query($sql);
    return $result;
}

function readInventory() {
    global $conn;
    $sql = "SELECT * FROM inventory ORDER BY id";
    $result = $conn->query($sql);
    $inventory = array();
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $inventory[] = $row;
        }
    }
    return $inventory;
}

function updateInventory($id, $nama_produk, $stok, $harga) {
    global $conn;
    $sql = "UPDATE inventory SET nama_produk = '$nama_produk', stok  ='$stok', harga = '$harga' WHERE id='$id'";
    if ($conn->query($sql) === TRUE) {
        $_SESSION['inventory_message'] = ["type" => "success", "message" => "Barang berhasil diupdate!"];
    } else {
        $_SESSION['inventory_message'] = ["type" => "danger", "message" => "Error updating record: " . $conn->error];
    }
}

function deleteInventory($id) {
    global $conn;
    $sql = "DELETE FROM inventory WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        $_SESSION['inventory_message'] = ["type" => "success", "message" => "Barang berhasil dihapus!"];
    } else {
        $_SESSION['inventory_message'] = ["type" => "danger", "message" => "Error deleting record: " . $conn->error];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    switch($action) {
        case 'create':
            $nama_produk = $_POST['nama_produk'];
            $stok = $_POST['stok'];
            $harga = $_POST['harga'];
            createInventory($nama_produk, $stok, $harga);
            break;

        case 'read':
            $response = json_encode(readInventory());
            break;

        case 'update':
            $id = $_POST['id'];
            $nama_produk = $_POST['nama_produk'];
            $stok = $_POST['stok'];
            $harga = $_POST['harga'];
            updateInventory($id, $nama_produk, $stok, $harga);
            break;

        case 'delete':
            $id = $_POST['id'];
            deleteInventory($id);
            break;

        default:
            $_SESSION['inventory_message'] = ["type" => "danger", "message" => "Invalid action"];
            break;
    }

    header("Location: /UAS_PW/inventory_page.php");
    exit();
}

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id = $_GET['id'];
    deleteInventory($id);

    header("Location: /UAS_PW/inventory_page.php");   
    exit();
}
?>
