<?php
if (!isset($_SESSION)) {
    session_start();
}

include 'connect.php';

function createorders($nama_produk, $qty, $total_harga, $order_date)
{
    global $conn;
    $sql = "INSERT INTO orders (nama_produk, qty, total_harga, order_date ) VALUES ('$nama_produk', '$qty','$total_harga', '$order_date')";
    if ($conn->query($sql) === TRUE) {
        $_SESSION['orders_message'] = ["type" => "success", "message" => "Barang berhasil ditambahkan!"];
    } else {
        $_SESSION['orders_message'] = ["type" => "danger", "message" => "Error: " . $sql . "<br>" . $conn->error];
    }
}

function readTotalQTy()
{
    global $conn;
    $sql = "SELECT SUM(qty) AS total_qty FROM orders ";
    $result = $conn->query($sql);
    return $result;
}

function readTotalHarga()
{
    global $conn;
    $sql = "SELECT SUM(total_harga) AS total_revenue FROM orders ";
    $result = $conn->query($sql);

    return $result;
}

function readTotalId()
{
    global $conn;
    $sql = "SELECT COUNT(id) AS total_customers FROM orders ";
    $result = $conn->query($sql);

    return $result;
}

function getTopSellingProducts()
{
    global $conn;
    $sql = "SELECT o.nama_produk AS product, 
            SUM(i.harga) AS price, 
            SUM(o.qty) AS sold, 
            SUM(i.harga * o.qty) AS revenue
            FROM orders o
            JOIN inventory i ON o.nama_produk = i.nama_produk
            GROUP BY o.nama_produk
            ORDER BY sold DESC
            LIMIT 10;";
    $result = $conn->query($sql);
    return $result;
}

function readorders()
{
    global $conn;
    $sql = "SELECT * FROM orders ORDER BY id ";
    $result = $conn->query($sql);
    $orders = array();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $orders[] = $row;
        }
    }
    return $orders;
}

function updateorders($id,$order_date)
{
    global $conn;
    $sql = "UPDATE orders SET order_date = '$order_date' WHERE id='$id'";
    if ($conn->query($sql) === TRUE) {
        $_SESSION['orders_message'] = ["type" => "success", "message" => "Barang berhasil diupdate!"];
    } else {
        $_SESSION['orders_message'] = ["type" => "danger", "message" => "Error updating record: " . $conn->error];
    }
}

function deleteorders($id)
{
    global $conn;
    $sql = "DELETE FROM orders WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        $_SESSION['orders_message'] = ["type" => "success", "message" => "Barang berhasil dihapus!"];
    } else {
        $_SESSION['orders_message'] = ["type" => "danger", "message" => "Error deleting record: " . $conn->error];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    switch ($action) {
        case 'create':
            $nama_produk = $_POST['nama_produk'];
            $qty = $_POST['quantity'];
            $total_harga = $_POST['total_harga'];
            $order_date = $_POST['order_date'];
            createorders($nama_produk, $qty, $total_harga, $order_date);
            break;

        case 'read':
            $response = json_encode(readorders());
            break;

        case 'update':
            $id = $_POST['id'];
            $order_date = $_POST['order_date'];
            updateorders($id, $order_date);
            break;

        case 'delete':
            $id = $_POST['id'];
            deleteorders($id);
            break;

        default:
            $_SESSION['orders_message'] = ["type" => "danger", "message" => "Invalid action"];
            break;
    }

    header("Location: /UAS_PW/orders_page.php");
    exit();
}


if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id = $_GET['id'];
    deleteorders($id);

    header("Location: /UAS_PW/orders_page.php");
    exit();
}
