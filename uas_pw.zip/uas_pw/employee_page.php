<?php
if (!isset($_SESSION)) {
  session_start();
}

$message = null;
if (isset($_SESSION['employee_message'])) {
  $message = $_SESSION['employee_message'];
  unset($_SESSION['employee_message']);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Tables / Karyawan - EsTeh</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>
  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">
    <div class="d-flex align-items-center justify-content-between">
      <a href="index.php" class="logo d-flex align-items-center">
        <img src="assets/img/logo.png" alt="">
        <span class="d-none d-lg-block">EsTeh</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div><!-- End Logo -->

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        <li class="nav-item dropdown pe-3">
          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <img src="assets/img/profile-img.jpg" alt="Profile" class="rounded-circle">
            <span class="d-none d-md-block dropdown-toggle ps-2"><?php echo $_SESSION['name']; ?></span>
          </a><!-- End Profile Iamge Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
            <li class="dropdown-header">
              <h6><?php echo $_SESSION['name']; ?></h6>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>
            <li>
              <a class="dropdown-item d-flex align-items-center" href="pages-login.php">
                <i class="bi bi-box-arrow-right"></i>
                <span>Sign Out</span>
              </a>
            </li>
          </ul><!-- End Profile Dropdown Items -->
        </li><!-- End Profile Nav -->
      </ul>
    </nav><!-- End Icons Navigation -->
  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
    <ul class="sidebar-nav" id="sidebar-nav">
      <li class="nav-item">
        <a class="nav-link collapsed" href="index.php">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li><!-- End Dashboard Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="inventory_page.php">
          <i class="bi bi-box-seam"></i>
          <span>Inventory</span>
        </a>
      </li><!-- End Profile Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="employee_page.php">
          <i class="bi bi-person-lines-fill"></i>
          <span>Employee</span>
        </a>
      </li><!-- End Profile Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="orders_page.php">
          <i class="bi bi-cart-check"></i>
          <span>Orders</span>
        </a>
      </li><!-- End Profile Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="pages-register.php">
          <i class="bi bi-card-list"></i>
          <span>Register</span>
        </a>
      </li><!-- End Register Page Nav -->
    </ul>
  </aside><!-- End Sidebar-->

  <main id="main" class="main">
    <!-- Toast Notification -->
    <?php if ($message) : ?>
      <div class="position-fixed top-0 end-0 p-3" id="employeeToast" style="z-index: 9999">
        <div id="liveToast" class="toast hide" role="alert" aria-live="assertive" aria-atomic="true">
          <div class="toast-header">
            <img src="assets\img\apple-touch-icon.png" class="rounded me-2" alt="..." width="24" height="24">
            <strong class="me-auto">Admin</strong>
            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
          </div>
          <div class="toast-body">
            <?php echo $message['message']; ?>
          </div>
        </div>
      </div>
    <?php endif; ?>

    <div class="pagetitle">
      <h1>Karyawan</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item active">Employees</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Daftar Karyawan</h5>
              <!-- Tombol Tambah -->
              <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#Tambah" id="tambah">Tambah Data</button>

              <!-- Modal Tambah -->
              <div class="modal fade" id="Tambah" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="staticBackdropLabel">Tambah Data Karyawan</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                      <!-- Div untuk pesan konfirmasi -->
                      <div id="confirmationMessage" class="alert alert-success d-none"></div>
                      <!-- Vertical Form -->
                      <form class="row g-3" method="POST" action="assets/php/employee.php">
                        <div class="col-12">
                          <label for="inputNama" class="form-label">Nama</label>
                          <input type="text" class="form-control" id="inputNama" name="nama" required>
                        </div>
                        <div class="col-12">
                          <label for="inputPosisi" class="form-label">Posisi</label>
                          <input type="text" class="form-control" id="inputPosisi" name="posisi" required>
                        </div>
                        <div class="col-12">
                          <label for="inputTanggalBergabung" class="form-label">Tanggal Bergabung</label>
                          <input type="date" class="form-control" id="inputTanggalBergabung" name="tanggal_masuk" required>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kembali</button>
                          <button type="submit" class="btn btn-primary" name="action" value="create">Simpan</button>
                        </div>
                      </form><!-- Vertical Form -->
                    </div>
                  </div>
                </div>
              </div><!--End Modal Tambah -->

              <!-- Tabel Karyawan -->
              <table class="table table-light table-striped">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Posisi</th>
                    <th>Tanggal Bergabung</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  include 'assets/php/employee.php';
                  $employees = readEmployees();
                  if (count($employees) > 0) {
                    foreach ($employees as $employee) {
                      echo "<tr>";
                      echo "<td>" . $employee['id'] . "</td>";
                      echo "<td>" . $employee['nama'] . "</td>";
                      echo "<td>" . $employee['posisi'] . "</td>";
                      echo "<td>" . $employee['tanggal_masuk'] . "</td>";
                      echo "<td>";
                      echo "<button class='btn btn-primary edit-employee' data-id='" . $employee['id'] . "' data-nama='" . $employee['nama'] . "' data-bs-toggle='modal' data-bs-target='#editEmployeeModal'>Edit</button> ";
                      echo "<button class='btn btn-danger delete-employee' data-id='" . $employee['id'] . "' data-nama='" . $employee['nama'] . "' data-bs-toggle='modal' data-bs-target='#confirmDelete'>Hapus</button>";
                      echo "</td>";
                      echo "</tr>";
                    }
                  } else {
                    echo "<tr><td colspan='5'>No results found</td></tr>";
                  }
                  ?>
                </tbody>
              </table>
              <!-- Tabel Karyawan -->

              <!-- Modal Konfirmasi Hapus -->
              <div class="modal fade" id="confirmDelete" tabindex="-1" aria-labelledby="confirmDeleteLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="confirmDeleteLabel">Konfirmasi Hapus Data</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                      Apakah Anda yakin ingin menghapus data <span id="employeeNameToDelete"></span>?
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                      <a id="deleteLink" href="#" class="btn btn-danger">Hapus</a>
                    </div>
                  </div>
                </div>
              </div>
              <!-- End Modal Konfirmasi Hapus -->

              <!-- Modal Edit Employee -->
              <div class="modal fade" id="editEmployeeModal" tabindex="-1" aria-labelledby="editEmployeeModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="editEmployeeModalLabel">Edit Data Karyawan</h5>
                    </div>
                    <div class="modal-body">
                      <form id="editEmployeeForm" action="assets/php/employee.php" method="POST">
                        <div class="mb-3">
                          <label for="edit_employee_id" class="form-label">ID</label>
                          <input type="text" class="form-control" style="background-color: #D3D3D3;" id="edit_employee_id" name="id" value="" readonly>
                        </div>
                        <div class="mb-3">
                          <label for="edit_employee_name" class="form-label">Nama</label>
                          <input type="text" class="form-control" id="edit_employee_name" name="nama" required>
                        </div>
                        <div class="mb-3">
                          <label for="edit_employee_position" class="form-label">Posisi</label>
                          <input type="text" class="form-control" id="edit_employee_position" name="posisi" required>
                        </div>
                        <div class="mb-3">
                          <label for="edit_employee_join_date" class="form-label">Tanggal Bergabung</label>
                          <input type="date" class="form-control" id="edit_employee_join_date" name="tanggal_masuk" required>
                        </div>
                        <div class="modal-footer">
                          <button type="submit" class="btn btn-primary" name="action" value="update">Simpan Perubahan</button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div> <!--End Modal Edit Employee -->
            </div>
          </div>
        </div>
      </div>
    </section>
    <div class="container mt-4">
  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>EsTeh</span></strong>. All Rights Reserved
    </div>
    <div class="credits">Designed by <a href="https://getbootstrap.com/docs/5.3/getting-started/introduction/">Bootstrap</a></div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script>
    <?php if ($message) : ?>
      var toastElement = document.getElementById('employeeToast');
      var toast = new bootstrap.Toast(liveToast);
      toast.show();
    <?php endif; ?>
  </script>

  <!-- Code injected by live-server -->
  <script>
    if ('WebSocket' in window) {
      (function() {
        function refreshCSS() {
          var sheets = [].slice.call(document.getElementsByTagName("link"));
          var head = document.getElementsByTagName("head")[0];
          for (var i = 0; i < sheets.length; ++i) {
            var elem = sheets[i];
            var parent = elem.parentElement || head;
            parent.removeChild(elem);
            var rel = elem.rel;
            if (elem.href && typeof rel != "string" || rel.length == 0 || rel.toLowerCase() == "stylesheet") {
              var url = elem.href.replace(/(&|\?)_cacheOverride=\d+/, '');
              elem.href = url + (url.indexOf('?') >= 0 ? '&' : '?') + '_cacheOverride=' + (new Date().valueOf());
            }
            parent.appendChild(elem);
          }
        }
        var protocol = window.location.protocol === 'http:' ? 'ws://' : 'wss://';
        var address = protocol + window.location.host + window.location.pathname + '/ws';
        var socket = new WebSocket(address);
        socket.onmessage = function(msg) {
          if (msg.data == 'reload') window.location.reload();
          else if (msg.data == 'refreshcss') refreshCSS();
        };
        if (sessionStorage && !sessionStorage.getItem('IsThisFirstTime_Log_From_LiveServer')) {
          console.log('Live reload enabled.');
          sessionStorage.setItem('IsThisFirstTime_Log_From_LiveServer', true);
        }
      })();
    } else {
      console.error('Upgrade your browser. This Browser is NOT supported WebSocket for Live-Reloading.');
    }
  </script>

  <!-- Script Untuk Edit Karyawan -->
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      // Mengatur data yang akan di-edit saat tombol "Edit" diklik
      var editButtons = document.querySelectorAll('.edit-employee');
      editButtons.forEach(function(button) {
        button.addEventListener('click', function() {
          var employeeId = button.getAttribute('data-id');
          var employeeName = button.closest('tr').querySelector('td:nth-child(2)').textContent.trim();
          var employeePosition = button.closest('tr').querySelector('td:nth-child(3)').textContent.trim();
          var employeeJoinDate = button.closest('tr').querySelector('td:nth-child(4)').textContent.trim();

          // Mengisi nilai input di dalam modal edit
          document.getElementById('edit_employee_id').value = employeeId;
          document.getElementById('edit_employee_name').value = employeeName;
          document.getElementById('edit_employee_position').value = employeePosition;
          document.getElementById('edit_employee_join_date').value = employeeJoinDate;

          // Tampilkan modal edit
          var editEmployeeModal = new bootstrap.Modal(document.getElementById('editEmployeeModal'));
          editEmployeeModal.show();
        });
      });
    });
  </script>

  <!-- Script Untuk Hapus Karyawan -->
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      var deleteButtons = document.querySelectorAll('.delete-employee');
      deleteButtons.forEach(function(button) {
        button.addEventListener('click', function() {
          var employeeName = button.getAttribute('data-nama');
          var employeeId = button.getAttribute('data-id');
          document.getElementById('employeeNameToDelete').textContent = employeeName;
          var deleteLink = document.getElementById('deleteLink');
          deleteLink.setAttribute('href', 'assets/php/employee.php?id=' + employeeId);
        });
      });
    });
  </script>
</body>

</html>